from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Flatten

class DeepANN:

    def simple_model(self):
        model = Sequential()
        model.add(Flatten())
        model.add(Flatten(input_shape=(124, 124)))
        model.add(Dense(256, activation="relu"))
        model.add(Dense(128, activation="relu"))
        model.add(Dense(9, activation="softmax"))
        model.compile(loss="categorical_crossentropy", optimizer="sgd", metrics=["accuracy"])
        return model