import SKILL_12_AutoEncoder as ac
import SKILL_12_ImgGen as ic
import matplotlib.pyplot as plt
if __name__ == "__main__":
    images_folder_path = 'train1'
    imgdg = ic.ImgDG()
    imgdg.visualize(images_folder_path, nimages=9)
    image_df, train, label = imgdg.preprocess(images_folder_path)
    image_df.to_csv("image_df.csv")
    tr_gen, tt_gen, va_gen = imgdg.generate_train_test_images(image_df, train, label)
    print("Length of Test Data Generated : ",len(tt_gen))

    auto = ac.AC()
    model = auto.autoencoder()
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',  # Mean Squared Error loss for reconstruction
                  metrics=['accuracy'])

    # Print the model summary
    model.summary()

    # Fit the model
    history = model.fit(tr_gen,
                        epochs=10,
                        validation_data=va_gen)
    print(model.summary())
    test_loss, test_accuracy = model.evaluate(tt_gen)
    print(f'Test accuracy: {test_accuracy}')

    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend(loc='lower right')
    plt.show()