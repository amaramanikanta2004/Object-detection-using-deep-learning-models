import SKILL_2 as fn

if __name__ == '__main__':
    images_folder_path = 'train1'
    imdata = fn.Preprocess_Data()
    imdata.visualize_images(images_folder_path, 9)
    image_df, train, label = imdata.preprocess(images_folder_path)
    image_df.to_csv("image_df.csv")
