from tensorflow.keras import layers, regularizers
from tensorflow.keras.layers import Dropout
from tensorflow.keras import models

class CNN_reg(models.Model):
    def __init__(self):
        super(CNN_reg, self).__init__()
        self.model = models.Sequential([
            layers.Conv2D(32, (3, 3), activation='selu', input_shape=(28, 28, 3), kernel_regularizer=regularizers.l1(0.01)),
            layers.MaxPooling2D((2, 2)),
            Dropout(0.25),
            layers.Conv2D(64, (3, 3), activation='selu'),
            layers.MaxPooling2D((2, 2)),
            Dropout(0.25),
            layers.Conv2D(64, (3, 3), activation='selu'),
            layers.Flatten(),
            layers.Dense(128, activation='selu', kernel_regularizer= regularizers.l2(0.01)),
            layers.Dense(64, activation='selu'),
            layers.Dense(9, activation='softmax'),
        ])
    def call(self, inputs):
        return self.model(inputs)
