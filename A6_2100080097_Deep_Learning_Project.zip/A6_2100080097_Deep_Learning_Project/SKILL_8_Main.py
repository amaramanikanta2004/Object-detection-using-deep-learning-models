import SKILL_8_RNN as cm
import SKILL_8_ImgGen as ic
import matplotlib.pyplot as plt
if __name__ == "__main__":
    images_folder_path = 'train1'
    imgdg = ic.ImgDG()
    imgdg.visualize(images_folder_path, nimages=9)
    image_df, train, label = imgdg.preprocess(images_folder_path)
    image_df.to_csv("image_df.csv")
    tr_gen, tt_gen, va_gen = imgdg.generate_train_test_images(image_df, train, label)
    print("Length of Test Data Generated : ",len(tt_gen))
    # CNN model
    # Create an instance of the custom model
    # Initialize the LSTM model with the input shape
    input_shape = (124, 124, 3)  # Input shape for 128x128x3 images
    num_classes = 9  # Example number of classes (adjust as needed)
    # Initialize the model with the input shape
    rnn = cm.RNN()
    Model = rnn.create_rnn_model(input_shape)
    # Train the model
    RNN_history = Model.fit(tr_gen, epochs=5, validation_data=va_gen)
    # Evaluate the model
    print(Model.summary())
    test_loss, test_accuracy = Model.evaluate(tt_gen)
    print(f'Test accuracy: {test_accuracy}')

    plt.plot(RNN_history.history['accuracy'], label='Training Accuracy')
    plt.plot(RNN_history.history['val_accuracy'], label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend(loc='lower right')
    plt.show()


