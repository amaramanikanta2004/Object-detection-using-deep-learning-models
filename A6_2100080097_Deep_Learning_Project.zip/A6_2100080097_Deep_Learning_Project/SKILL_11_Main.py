import SKILL_11_AutoEncoder as ac
import SKILL_11_ImgGen as ic
import matplotlib.pyplot as plt
from tensorflow.keras import models
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense

if __name__ == "__main__":
    images_folder_path = 'train1'
    imgdg = ic.ImgDG()
    imgdg.visualize(images_folder_path, nimages=9)
    image_df, train, label = imgdg.preprocess(images_folder_path)
    image_df.to_csv("image_df.csv")
    tr_gen, tt_gen, va_gen = imgdg.generate_train_test_images(image_df, train, label)

    model_autoencoder = ac.AC().autoencoder()

    # Generate
    # ResNet50 model
    base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(128, 128, 3))
    base_model.trainable = False

    x = GlobalAveragePooling2D()(base_model.output)
    output = Dense(2, activation='softmax')(x)  # Binary classification with 2 units

    model = models.Model(inputs=base_model.input, outputs=output)
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

    print("Model Summary:")
    print(model.summary())

    history = model.fit(tr_gen, validation_data=(va_gen), epochs=10)

    test_loss, test_accuracy = model.evaluate(tt_gen)
    print(f'Test accuracy: {test_accuracy}')

    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend(loc='lower right')
    plt.show()
