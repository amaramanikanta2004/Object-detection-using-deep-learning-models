from tensorflow.keras.layers import Dense, Flatten, SimpleRNN, Reshape
from tensorflow.keras import Sequential
class RNN:
    def create_rnn_model(self, input_shape, num_classes=9):
        model = Sequential()
        # Reshape layer to flatten the input images 124,124,3
        model.add(Reshape((-1, input_shape[2]), input_shape=input_shape))
        # RNN layer
        model.add(SimpleRNN(124))  # Adjust units as needed
        # Fully connected layers
        model.add(Dense(64, activation='relu'))  # Adjust units as needed
        model.add(Dense(num_classes, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model
