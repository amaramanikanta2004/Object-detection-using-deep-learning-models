import SKILL_3_class as ic
import SKILL_3_model as mm


if __name__ == '__main__':
    images_folder_path = 'train'
    imd = ic.ImgDG()
    imd.visualize(images_folder_path, nimages=9)
    image_df, train, label = imd.preprocess(images_folder_path)
    image_df.to_csv("image_df.csv")
    tr_gen, tt_gen, va_gen = imd.generate_train_test_images(image_df, train, label)
    AnnModel = mm.DeepANN()
    Model1 = AnnModel.simple_model()
    print("train generator", len(tr_gen))
    ANN_history = Model1.fit(
        tr_gen,
        epochs=10,
        validation_data=va_gen)
    Ann_test_loss, Ann_test_acc = Model1.evaluate(tt_gen)
    print(f'Test accuracy: {Ann_test_acc}')
    Model1.save("my_model1.keras")
    print("the ann architecture is")
    print(Model1.summary())
    '''plt.figure(1, 2,1)
    plt.subplot()'''