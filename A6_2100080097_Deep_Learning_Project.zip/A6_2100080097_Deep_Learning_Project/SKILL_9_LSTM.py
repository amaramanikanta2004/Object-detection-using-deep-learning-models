from tensorflow.keras.layers import Dense, Flatten, LSTM, Reshape, Conv2D, MaxPooling2D
from tensorflow.keras import Sequential

class LSTM_Model():
    def create_lstm_model(self, input_shape, num_classes):
        model = Sequential()
        # Convolutional layers
        model.add(Conv2D(124, kernel_size=(3, 3), activation='relu', input_shape=input_shape))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        # Reshape layer
        model.add(Reshape((-1, model.output_shape[1]), input_shape=model.output_shape[1:]))
        # LSTM layer
        model.add(LSTM(128))  # Adjust units as needed
        # Fully connected layer
        model.add(Dense(64, activation='relu'))  # Adjust units as needed
        model.add(Dense(num_classes, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model
